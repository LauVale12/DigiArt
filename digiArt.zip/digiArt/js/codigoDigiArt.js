const canvas = document.getElementById('myCanvas');
